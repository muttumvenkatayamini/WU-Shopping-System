package com.cartServicet.demo.CartDto;

import lombok.*;


@Data
public class CartDtoResponse {
	
	private Long cartId;
	private String Response;

}
