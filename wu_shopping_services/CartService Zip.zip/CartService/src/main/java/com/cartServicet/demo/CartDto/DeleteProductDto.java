package com.cartServicet.demo.CartDto;

import lombok.*;


@Data
public class DeleteProductDto {
	
	private Long cartId;
	
	private Long ProductId;

}
