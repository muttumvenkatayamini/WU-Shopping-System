package com.cartServicet.demo.CartDto;

import lombok.*;

/**
 * 
 * @author muttum.venkatayamini
 *
 */

@Data
public class FetchCartDto {
	
	private Long cartId;

}
