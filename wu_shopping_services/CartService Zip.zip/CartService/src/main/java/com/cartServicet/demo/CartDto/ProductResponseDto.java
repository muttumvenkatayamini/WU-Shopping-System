package com.cartServicet.demo.CartDto;

import lombok.Data;




@Data
public class ProductResponseDto {

	private Long productId;

	private int quantity;

	private double price;
	

}
