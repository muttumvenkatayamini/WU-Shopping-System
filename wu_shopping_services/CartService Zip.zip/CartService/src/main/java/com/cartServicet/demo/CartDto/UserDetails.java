package com.cartServicet.demo.CartDto;

import lombok.Data;

@Data
public class UserDetails {
	
	private String sessionId;
	
	private String userName;
	
	private Long userId;

}
