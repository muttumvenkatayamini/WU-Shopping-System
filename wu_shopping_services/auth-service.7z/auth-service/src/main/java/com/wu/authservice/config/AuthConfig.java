package com.wu.authservice.config;

import static org.springframework.boot.autoconfigure.security.servlet.PathRequest.toH2Console;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.authentication.configurers.userdetails.DaoAuthenticationConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.wu.authservice.service.CustomUserDetailService;

@Configuration
@EnableWebSecurity
public class AuthConfig {
	
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//		return http.csrf().disable()
//		.authorizeHttpRequests().requestMatchers("/auth/register","/auth/token","/auth/validate")
//		.permitAll().and().authorizeHttpRequests().requestMatchers(antMatcher("/h2-console/**")).permitAll()
//		.and()
//		.build();
//		return http.csrf().disable()
//				.authorizeHttpRequests().requestMatchers("/auth/register","/auth/token","/auth/validate")
//				.permitAll().and().authorizeHttpRequests().requestMatchers(toH2Console()).permitAll().and()
//				.csrf().ignoringRequestMatchers(toH2Console())
//				.and()
//				.build();
		//Working
		return http.csrf().disable()
				.authorizeHttpRequests().requestMatchers("/auth/register","/auth/token","/auth/validate")
				.permitAll().and().authorizeHttpRequests().requestMatchers(toH2Console()).permitAll()
				.and().headers().frameOptions().sameOrigin().and()
				.build();
		
//		return http
//				.authorizeHttpRequests().requestMatchers("/h2-console/**").permitAll().anyRequest().authenticated()
//				.and().csrf().ignoringRequestMatchers("/h2-console/**").and().headers().frameOptions().sameOrigin()
//				.and()
//				.build();
//		return http.csrf().disable()
//		.authorizeHttpRequests().requestMatchers("/auth/register","/auth/token","/auth/validate","/h2-console/**")
//		.permitAll()
//		.and()
//		.build();
		
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
		
	}
	
	@Bean
	public UserDetailsService userDetailsService() {
		return new CustomUserDetailService();
		
	}
	
	@Bean
	public AuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
		authenticationProvider.setUserDetailsService(userDetailsService());
		authenticationProvider.setPasswordEncoder(passwordEncoder());
		return authenticationProvider;
		
	}
	
	
}
